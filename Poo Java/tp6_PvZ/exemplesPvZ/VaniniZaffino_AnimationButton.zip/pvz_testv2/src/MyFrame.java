import javax.swing.*;


public class MyFrame extends JFrame {

    //Default init size for the frame
    private static int WIDTH = 1000;
    private static int HEIGHT = 200;


    private ContainerPanel cp;


    public MyFrame() {

        cp = new ContainerPanel();

        this.setTitle("TP5");
        this.setSize(WIDTH, HEIGHT);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setContentPane(cp);
        this.setVisible(true);
    }
}
