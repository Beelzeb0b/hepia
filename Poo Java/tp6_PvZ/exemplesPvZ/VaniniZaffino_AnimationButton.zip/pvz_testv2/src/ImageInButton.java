import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ImageInButton extends JPanel implements ActionListener {
    public ImageInButton(){

        //this.setBackground(Color.RED);

        JButton button = new JButton();
        button.addActionListener(this);
        this.add(button,BorderLayout.CENTER);

        try {
            Image img = ImageIO.read(Main.class.getResource("img/penguin.png"));
            button.setIcon(new ImageIcon(img));
        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("click");
    }
}
