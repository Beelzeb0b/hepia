import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ButtonImage extends JPanel implements ActionListener {

    public ButtonImage() {

        this.setBackground(Color.GRAY);

        JButton button = new JButton();
        this.add(button, BorderLayout.CENTER);
        button.addActionListener(this);

        try {
            //load the image
            Image img = ImageIO.read(Main.class.getResource("img/penguin.png"));

            //Put the loaded image in the button
            button.setIcon(new ImageIcon(img));

            //remove the border
            button.setBorder(BorderFactory.createEmptyBorder());
            button.setContentAreaFilled(false);

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        System.out.println("click");
    }
}
