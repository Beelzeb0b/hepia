import javax.swing.*;
import java.awt.*;

public class ContainerPanel extends JPanel {

    private GifPanel gp;
    private ButtonImage bi;
    private ImageInButton iib;


    public ContainerPanel() {

        gp = new GifPanel();
        bi = new ButtonImage();
        iib = new ImageInButton();

        this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        this.add(gp, BorderLayout.WEST);
        this.add(iib);
        this.add(bi);


    }

}
