import javax.swing.*;
import java.awt.*;

public class GifPanel extends JPanel {

    private Image gif;

    public GifPanel() {
        //load the gif
        this.gif = new ImageIcon(Main.class.getResource("gif/g.gif")).getImage();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(gif, 0, 0, getWidth(), getHeight(), this);
    }
}
