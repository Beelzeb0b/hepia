import javax.swing.*;

import static java.lang.System.out;

public class Model {
    private Controler ctr;

    public Controler getCtr() {
        return ctr;
    }
    public void setCtr(Controler ctr) {
        this.ctr = ctr;
    }

    public Model(Controler ctr) {
        this.ctr = ctr;
    }

    public void start()
    {
        out.println(122);
    }

}
