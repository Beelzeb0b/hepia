public class View{
    private Controler ctr;

    public  View()
        {

            Controler ctr = new Controler(this);
            ctr.start();
        }

        }