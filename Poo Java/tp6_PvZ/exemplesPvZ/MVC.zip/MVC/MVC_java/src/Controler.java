public class Controler
{
    private View frame;
    private Model m;

//GETTER SETTER (ENCAPSUlATION)
    public Model getM() {
        return m;
    }
    public void setM(Model m) {
        this.m = m;
    }


    public View getFrame() {
        return frame;
    }
    public void setFrame(View frame) {
        this.frame = frame;
    }

    public Controler(View v)
    {
        this.setFrame(v);
        this.setM(new Model(this));

    }
    public void start()
    {
        this.m.start();
    }

}