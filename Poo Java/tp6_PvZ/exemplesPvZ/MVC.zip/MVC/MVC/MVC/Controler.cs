﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MVC
{
    public class Controler
    {
        View _frm;
        Model _mdl;

        public Model Mdl
        {
            get { return _mdl; }
            set { _mdl = value; }
        }
        public View Frm
        {
            get { return _frm; }
            set { _frm = value; }
        }



        public Controler(View View)
        {
            this.Frm = View;
            this.Mdl = new Model(this);
        }
    }
}
