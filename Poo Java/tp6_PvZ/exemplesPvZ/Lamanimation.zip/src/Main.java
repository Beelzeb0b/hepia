public class Main {

    public static void main(String[] args) {
        Fenetre f = new Fenetre();
        f.setVisible(true);
    }
}
