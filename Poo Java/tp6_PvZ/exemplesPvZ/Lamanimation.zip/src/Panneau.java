import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import javax.swing.JPanel;
import javax.imageio.ImageIO;

public class Panneau extends JPanel {

    private BufferedImage image;
    private int posX = -2000;
    private int posY = 150;

    public Panneau(String chemin){
        try {
			//CREATION IMAGE
            this.image = ImageIO.read(new File(chemin));
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
    public void paintComponent(Graphics g){

        g.setColor(Color.white);
        g.fillRect(0,0,this.getWidth(),this.getHeight());

        for(int i = 0; i<20;i++) {
			//DESSINER IMAGE
            g.drawImage(image, posX + i * 100, posY + (i % 2) * 100, null);
        }

    }

    public int getPosX() {
        return posX;
    }

    public void setPosX(int posX) {
        this.posX = posX;
    }

    public int getPosY() {
        return posY;
    }

    public void setPosY(int posY) {
        this.posY = posY;
    }
}
