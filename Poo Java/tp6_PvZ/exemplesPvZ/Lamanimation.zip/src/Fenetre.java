import javax.swing.JFrame;

public class Fenetre extends JFrame{

    private Panneau pan = new Panneau("alpaga.png");

    public Fenetre(){
        this.setTitle("Animation");
        this.setSize(500,500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setContentPane(pan);
        this.setVisible(true);
        go();
    }
    private void go(){
        for (int i = -2000; i<pan.getWidth(); i++){
            int x = pan.getPosX(), y = pan.getPosY();
            x++;

            if(i%30 == 0){
                y += 25;
            }else{
                if(i%15 == 0){
                    y -= 25;
                }
            }

            pan.setPosY(y);
            pan.setPosX(x);
            pan.repaint();

            try{
                Thread.sleep(10);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }
    }
}
