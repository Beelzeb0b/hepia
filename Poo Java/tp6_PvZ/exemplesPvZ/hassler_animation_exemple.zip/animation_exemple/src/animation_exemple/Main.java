package animation_exemple;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


 class GifPanel extends JPanel {
	  Image image;
	  Timer tmr;
	  Point position;

	  public GifPanel(String img_path) {
	    image = Toolkit.getDefaultToolkit().createImage(img_path);
	    position= new Point(0,50);
	    tmr= new Timer(10, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				position.x+=2;	
				repaint();
			}
		});
	    
	    tmr.start();
	  }
	    
	  @Override
	  public void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    if (image != null) {
	      g.drawImage(image, position.x, position.y, this);
	    }
	  }
}
 
 class SpritePanel extends JPanel {
	  BufferedImage original_image;
	  Image sprite;
	  Timer tmr;
	  Point position;
	  int nb_sprites;
	  int sprite_pos;
	  int sprite_cnt;
	  int s_width;
	  int s_height;

	  
	  
	  
	  public SpritePanel(String img_path,  int nb_sprite,  int sprite_width, int sprite_height) {
		  	
		  this.nb_sprites=nb_sprite;
		  this.sprite_pos=0;
		  this.sprite_cnt=1;
		  this.s_width=sprite_width;
		  this.s_height=sprite_height;
		  position= new Point(400,50);
		  try {
			original_image = ImageIO.read(new File(img_path));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	      sprite=original_image;
		
	   
	    tmr= new Timer(50, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				sprite = original_image.getSubimage(sprite_pos, 0, (s_width/nb_sprites), s_height);
				if(sprite_cnt==nb_sprites) {
					sprite_pos=0;
					sprite_cnt=1;
				}else {
					sprite_pos+=(s_width/nb_sprites);
					sprite_cnt++;
				}
				position.x-=3;
				repaint();
			}
		});
	    
	    tmr.start();
	  }
	    
	  @Override
	  public void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    if (sprite != null) {
	      g.drawImage(sprite, position.x, position.y, this);
	    }
	  }
}
 

public class Main {
	
	public static void main(String arg[]) {
		JFrame f = new JFrame();
		GifPanel gif = new GifPanel("sonic.gif");
		SpritePanel sprite = new SpritePanel("explosion.png",12,1602,134);
		f.add(sprite);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setLocationRelativeTo(null);
		f.setTitle("Animation exemple");
		f.setSize(500, 500);
		
		f.setVisible(true);
	}

}
